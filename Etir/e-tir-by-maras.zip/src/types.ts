export type Language = 'en' | 'tr' | 'ar';

export type UserRole = 'admin' | 'driver';

export type ShipmentStatus =
  | 'New'
  | 'Assigned'
  | 'Accepted'
  | 'Loading'
  | 'Loaded'
  | 'In Transit'
  | 'Border Crossing'
  | 'Customs Clearance'
  | 'Arrived'
  | 'Delivered'
  | 'Closed'
  // Sea statuses
  | 'Booking Confirmed'
  | 'Container Released'
  | 'Loaded on Vessel'
  | 'Vessel Departed'
  | 'Arrived at Port'
  | 'Released'
  | 'Out for Delivery'
  | 'Completed'
  // Air statuses
  | 'Cargo Received'
  | 'Security Check Completed'
  | 'Departed Airport'
  | 'Arrived Airport';

export type Currency = 'USD' | 'IQD' | 'TRY';

export type DocumentCategory =
  | 'cmr'
  | 'invoice'
  | 'packing_list'
  | 'customs'
  | 'delivery_proof'
  | 'photo'
  | 'other';

export interface ShipmentDocument {
  id: string;
  name: string;
  url: string;
  category: DocumentCategory;
  uploadedBy: string;
  uploadedAt: string;
  isSharedExternally: boolean;
}

export interface LocationUpdate {
  timestamp: string;
  status: ShipmentStatus;
  labelEn: string;
  labelTr: string;
  labelAr: string;
  detailsEn?: string;
  detailsTr?: string;
  detailsAr?: string;
}

export interface Shipment {
  id: string;
  shipmentNumber: string;
  companyName: string; // Admin only
  loadingCountry: string;
  loadingCity: string;
  loadingAddress: string;
  loadingContactNumber: string;
  deliveryCountry: string;
  deliveryCity: string;
  deliveryAddress: string;
  deliveryContactNumber: string;
  cargoDescription: string;
  cargoWeight: number; // in kg
  truckNumber: string;
  assignedDriverId: string;
  assignedDriverName: string;
  agreedAmount: number;
  currency: Currency;
  internalNotes: string; // Admin only
  status: ShipmentStatus;
  documents: ShipmentDocument[];
  timeline: LocationUpdate[];
  createdAt: string;
  updatedAt: string;
  isLinkShared: boolean;
  shareToken: string;
  shareIncludeDocuments: boolean;
  shareIncludePhotos: boolean;
  
  // Sea & Air properties
  freightType?: 'land' | 'sea' | 'air';
  // Sea precise
  shippingLine?: string;
  vesselName?: string;
  containerNumber?: string;
  bookingNumber?: string;
  billOfLadingNumber?: string;
  portOfLoading?: string;
  portOfDischarge?: string;
  finalDestination?: string;
  etd?: string;
  eta?: string;
  numberOfContainers?: number;
  containerType?: string;
  // Air precise
  airline?: string;
  flightNumber?: string;
  airWaybillNumber?: string;
  airportOfDeparture?: string;
  airportOfArrival?: string;
  grossWeight?: number;
  chargeableWeight?: number;
  numberOfPackages?: number;
}

export interface Driver {
  id: string;
  name: string;
  username: string;
  password?: string;
  truckNumber: string;
  phone: string;
  activeShipmentsCount: number;
  completedShipmentsCount: number;
  truckType?: string;
  latitude?: number;
  longitude?: number;
  lastUpdated?: string;
  avatarUrl?: string;
}

export interface Client {
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  email: string;
  address: string;
  notes?: string;
  createdAt: string;
}

export interface Vendor {
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  email: string;
  address: string;
  serviceType: string;
  notes?: string;
  createdAt: string;
}

export const TRUCK_TYPES = [
  { id: "reefer", en: "Refrigerated (Reefer)", tr: "Frigorifik (Frigo)", ar: "مبردة (ثلاجة)" },
  { id: "curtainsider", en: "Curtainsider (Tilt)", tr: "Tenteli Dorse", ar: "جوانب ستائر" },
  { id: "flatbed", en: "Flatbed", tr: "Açık Kasa (Sal)", ar: "مسطحة" },
  { id: "lowboy", en: "Lowboy (Heavy Haul)", tr: "Alçak Şasi (Lowbed)", ar: "منخفضة للحمولات الثقيلة" },
  { id: "dryvan", en: "Box / Dry Van", tr: "Kapalı Kasa", ar: "صندوق مغلق" },
  { id: "tanker", en: "Tanker", tr: "Tanker", ar: "ناقلة سوائل / تانكر" }
];

export interface ChatMessage {
  id: string;
  shipmentId: string;
  sender: 'admin' | 'driver';
  senderName: string;
  type: 'text' | 'file';
  text?: string;
  fileUrl?: string;
  fileName?: string;
  fileCategory?: DocumentCategory;
  timestamp: string;
  status?: 'sent' | 'seen';
}

export interface ActivityLog {
  id: string;
  shipmentId: string;
  shipmentNumber: string;
  actionEn: string;
  actionTr: string;
  actionAr: string;
  actor: string;
  timestamp: string;
}

export interface AppNotification {
  id: string;
  shipmentId: string;
  shipmentNumber: string;
  titleEn: string;
  titleTr: string;
  titleAr: string;
  messageEn: string;
  messageTr: string;
  messageAr: string;
  type: 'assignment' | 'acceptance' | 'rejection' | 'status_update' | 'chat' | 'doc_upload' | 'delivery';
  timestamp: string;
  read: boolean;
}

export interface CostItem {
  id: string;
  costType: string;
  description: string;
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  currency: Currency;
  supplierName: string;
  documentUrl?: string;
  documentName?: string;
  internalNotes?: string;
}

export interface CostStatement {
  shipmentId: string;
  shipmentNumber: string;
  companyName: string;
  shipmentType: 'land' | 'sea' | 'air';
  date: string;
  currency: Currency;
  totalCost: number;
  paidAmount: number;
  remainingBalance: number;
  paymentStatus: 'Unpaid' | 'Partial' | 'Paid';
  notes: string;
  items: CostItem[];
  createdAt: string;
  updatedAt: string;
}

